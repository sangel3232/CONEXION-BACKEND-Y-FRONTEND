package com.example.demo.models.Service;

import com.example.demo.models.Entity.Cliente;

import java.util.List;

public interface IClienteService {
    public List<Cliente> findAll();
}
